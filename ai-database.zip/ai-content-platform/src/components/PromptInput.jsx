// src/components/PromptInput.jsx
import { useState } from 'react'

function PromptInput({ onNewPrompt }) {
  const [inputValue, setInputValue] = useState("");
  const [tagInput,setTagInput]=useState("");
  const [tags,setTags]=useState([]);

  return (
    <footer style={{
      position: 'fixed',
      bottom: 0,
      left: '260px',
      width: 'calc(100% - 260px)',
      backgroundColor: '#1f2428',
      padding: '20px',
      borderTop: '1px solid #30363d',
      display: 'flex',
      justifyContent: 'center',
      boxSizing: 'border-box',
      zIndex: 50 // 確保它浮在內容上面，但在側邊欄下面
    }}>
      <div style={{ maxWidth: '800px', width: '100%', display: 'flex', gap: '10px' }}>
        {/* 1. 新增：標籤輸入框 (放在最左邊) */}
        <input 
          type="text" 
          placeholder="標籤..." 
          style={{
            width: '100px', // 固定寬度，不佔太多空間
            padding: '12px',
            marginRight: '10px', // 跟右邊的內容保持距離
            borderRadius: '6px',
            border: '1px solid #30363d',
            backgroundColor: '#0d1117',
            color: '#58a6ff', // 用藍色字體區分標籤
            outline: 'none'
          }}
          value={tagInput}
          onChange={(e) => setTagInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              if (tagInput.trim()) {
                setTags([...tags, tagInput.trim()]);
                setTagInput(""); // 清空輸入框
              }
            }
          }}
        />
        {/* 2. 新增：顯示已經輸入的標籤 */}
        {tags.map((tag, index) => (
          <span 
            key={index} 
            style={{
              backgroundColor: '#1f6feb', // 藍色底
              color: 'white',
              padding: '5px 10px',
              borderRadius: '15px',
              fontSize: '0.85rem',
              marginRight: '8px', // 標籤之間的距離
              whiteSpace: 'nowrap' // 防止文字換行
            }}
          >
            #{tag}
          </span>
        ))}
        <input 
          type="text" 
          placeholder="輸入您的 Prompt 來生成內容..." 
          style={{
            flex: 1,
            padding: '12px',
            borderRadius: '6px',
            border: '1px solid #30363d',
            backgroundColor: '#0d1117',
            color: 'white',
            outline: 'none'
          }}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
        />
        <button 
          style={{
            padding: '10px 20px',
            backgroundColor: '#238636',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontWeight: 'bold'
          }}
          onClick={() => {
            if (inputValue.trim()) {
              onNewPrompt(inputValue, tags); // (新的) 傳送 內容 + 標籤
              setInputValue("");
              setTags([]);                   // (新的) 清空標籤暫存
            }
          }}
        >
          生成
        </button>
      </div>
    </footer>
  )
}

export default PromptInput