// src/components/Sidebar.jsx

// 1. 記得在括號裡加上 user 和 onLogout
function Sidebar({ projects, activeProjectId, onSelect, user, onLogout }) {
  return (
    <aside style={{
      width: '260px',
      height: '100vh',
      backgroundColor: '#0d1117',
      color: 'white',
      display: 'flex',
      flexDirection: 'column', // 讓內容由上往下排
      padding: '10px',
      boxSizing: 'border-box',
      position: 'fixed',
      left: 0,
      top: 0,
      borderRight: '1px solid #30363d'
    }}>
      {/* 上半部：標題與列表 */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <h2 style={{ padding: '0 10px', fontSize: '1.2rem', marginBottom: '20px' }}>
          🤖 AI Content Pro
        </h2>
        
        <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
          {projects.map(project => (
            <div 
              key={project.id}
              onClick={() => onSelect(project.id)}
              style={{
                padding: '10px',
                borderRadius: '6px',
                cursor: 'pointer',
                backgroundColor: activeProjectId === project.id ? '#1f6feb' : 'transparent',
                transition: '0.2s'
              }}
            >
              {project.name}
            </div>
          ))}
        </div>
      </div>

      {/* ★★★ 2. 下半部：使用者資訊區塊 (新增在這裡) ★★★ */}
      {user && (
        <div style={{ 
          marginTop: 'auto', // 這行魔法語法會把這個區塊「推」到最下面
          borderTop: '1px solid #30363d', 
          paddingTop: '15px' 
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px', padding: '0 5px' }}>
            <span style={{ fontSize: '1.5rem' }}>{user.avatar}</span>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <span style={{ fontWeight: 'bold', fontSize: '0.9rem' }}>{user.name}</span>
              <span style={{ fontSize: '0.75rem', color: '#8b949e', border: '1px solid #30363d', borderRadius: '4px', padding: '0 4px', width: 'fit-content' }}>
                {user.role}
              </span>
            </div>
          </div>
          
          <button 
            onClick={onLogout}
            style={{
              width: '100%',
              padding: '8px',
              backgroundColor: '#21262d',
              border: '1px solid #30363d',
              color: '#c9d1d9',
              borderRadius: '6px',
              cursor: 'pointer'
            }}
          >
            🚪 登出系統
          </button>
        </div>
      )}
    </aside>
  )
}

export default Sidebar