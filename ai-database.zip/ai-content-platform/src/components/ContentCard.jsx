// src/components/ContentCard.jsx
import { useState } from 'react'

function ContentCard({ id, version, date, prompt, response, tags, onDelete, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editPrompt, setEditPrompt] = useState(prompt);
  const [editResponse, setEditResponse] = useState(response);

  return (
    <div style={{
      backgroundColor: '#2b3137',
      border: '1px solid #30363d',
      borderRadius: '6px',
      padding: '20px',
      marginBottom: '20px',
      color: '#e6edf3',
      position: 'relative',
      display: 'flex',       // 1. 讓內容垂直排列
      flexDirection: 'column'
    }}>

      {/* 刪除按鈕 (固定在右上角) */}
      <button 
        onClick={() => onDelete(id)}
        style={{
          position: 'absolute',
          top: '15px',
          right: '15px',
          backgroundColor: 'transparent',
          border: 'none',
          cursor: 'pointer',
          fontSize: '1.2rem',
          padding: '5px',
          opacity: 0.6,
          transition: 'opacity 0.2s',
          zIndex: 10 // 確保它浮在最上層
        }}
        title="刪除此版本"
        onMouseOver={(e) => e.target.style.opacity = 1}
        onMouseOut={(e) => e.target.style.opacity = 0.6}
      >
        🗑️
      </button>

      {/* 頂部資訊 (版本與日期) */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px', fontSize: '0.85rem', color: '#8b949e', paddingRight: '30px' }}>
        <span>版本: {version}</span>
        <span>{date}</span>
      </div>

      {/* 標籤區 */}
      {tags && tags.length > 0 && (
        <div style={{ marginBottom: '15px', display: 'flex', gap: '8px' }}>
          {tags.map((tag, index) => (
            <span key={index} style={{
              backgroundColor: '#1f6feb',
              color: 'white',
              fontSize: '0.75rem',
              padding: '2px 8px',
              borderRadius: '12px',
              fontWeight: 'bold'
            }}>
              #{tag}
            </span>
          ))}
        </div>
      )}

{/* User 提詞區：改成靠右的藍色氣泡 */}
      <div style={{ marginBottom: '15px', display: 'flex', justifyContent: 'flex-end' }}>
        {isEditing ? (
          <textarea 
            style={{ width: '100%', padding: '10px', marginTop: '5px', borderRadius: '6px', backgroundColor: '#0d1117', color: 'white', border: '1px solid #30363d', minHeight: '60px' }}
            value={editPrompt} 
            onChange={(e) => setEditPrompt(e.target.value)}
          />
        ) : (
          <div style={{ maxWidth: '80%' }}>
            {/* 這裡我們把 "User:" 文字拿掉，直接用氣泡顯示 */}
            <p style={{ 
              margin: '0', 
              padding: '12px 16px', 
              backgroundColor: '#1f6feb', // 藍色背景
              color: 'white',
              borderRadius: '18px 18px 4px 18px', // 特殊圓角
              display: 'inline-block',
              textAlign: 'left',
              fontSize: '1rem',
              lineHeight: '1.5',
              boxShadow: '0 1px 2px rgba(0,0,0,0.2)'
            }}>
              {prompt}
            </p>
          </div>
        )}
      </div>

{/* AI 回應區：改成靠左的氣泡 + 機器人圖示 */}
      <div style={{ flex: 1, display: 'flex', marginBottom: '20px' }}>
        
        {/* 1. 左邊放一個機器人頭像 */}
        <div style={{ 
          width: '35px', 
          height: '35px', 
          borderRadius: '50%', 
          backgroundColor: '#3fb950', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          marginRight: '12px',
          fontSize: '1.2rem'
        }}>
          🤖
        </div>

        {/* 2. 右邊放對話內容 */}
        <div style={{ maxWidth: '85%' }}>
          <strong style={{ display: 'block', color: '#8b949e', marginBottom: '4px', fontSize: '0.85rem' }}>AI Bot</strong>
          
          {isEditing ? (
            <textarea
              style={{ width: '100%', padding: '10px', borderRadius: '6px', backgroundColor: '#0d1117', color: 'white', border: '1px solid #30363d', minHeight: '100px' }}
              value={editResponse}
              onChange={(e) => setEditResponse(e.target.value)}
            />
          ) : (
            <p style={{ 
              margin: '0', 
              padding: '12px 16px', 
              backgroundColor: '#21262d', // 深灰色背景
              color: '#e6edf3',
              borderRadius: '0px 18px 18px 18px', // 左上角是尖的
              lineHeight: '1.6'
            }}>
              {response}
            </p>
          )}
        </div>
      </div>

      {/* ★★★ 編輯按鈕區 (搬到最下面了！) ★★★ */}
      <div style={{ marginTop: '20px', paddingTop: '15px', borderTop: '1px solid #30363d', display: 'flex', justifyContent: 'flex-end' }}>
        {isEditing ? (
          <>
            <button 
              style={{ padding: '8px 16px', backgroundColor: '#238636', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', marginRight: '10px', fontWeight: 'bold' }}
              onClick={() => {
                onUpdate(id, editPrompt, editResponse);
                setIsEditing(false);
              }}
            >
              儲存變更
            </button>
            <button 
              style={{ padding: '8px 16px', backgroundColor: '#d73a49', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}
              onClick={() => {
                setIsEditing(false);
                setEditPrompt(prompt);
                setEditResponse(response);
              }}
            >
              取消
            </button>
          </>
        ) : (
          <button 
            style={{ padding: '8px 16px', backgroundColor: '#1f6feb', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}
            onClick={() => setIsEditing(true)}
          >
            ✏️ 編輯內容
          </button>
        )}
      </div>

    </div>
  )
}

export default ContentCard