import { useState } from 'react'
import { initialProjects } from './mockData'
import './App.css'
import Header from './components/Header'
import ContentCard from './components/ContentCard'
import PromptInput from './components/PromptInput'
import Sidebar from './components/Sidebar'

// 模擬的使用者資料
const mockUser = {
  id: 'user_001',
  name: '林學熙',
  avatar: '👨‍💻',
  role: 'owner'   // 之後可以用這個來測試權限 (owner/editor/viewer)
};

// 這是我們新做的登入頁元件
function LoginPage({ onLogin }) {
  return (
    <div style={{ 
      height: '100vh', 
      display: 'flex', 
      flexDirection: 'column', 
      alignItems: 'center', 
      justifyContent: 'center', 
      backgroundColor: '#0d1117', 
      color: 'white' 
    }}>
      <h1>🔐 請先登入</h1>
      <button 
        onClick={onLogin}
        style={{ padding: '10px 20px', fontSize: '1.2rem', cursor: 'pointer', backgroundColor: '#238636', color: 'white', border: 'none', borderRadius: '6px' }}
      >
        登入系統
      </button>
    </div>
  );
}

function App() {
  // 1. 建立一個狀態來記錄「是否登入」，預設是 false (未登入)
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [projects, setProjects] = useState(initialProjects);
  const [activeProjectId, setActiveProjectId] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
    // 🚪 守門員：如果還沒登入，就直接顯示登入頁，不往下執行
  if (!isLoggedIn) {
    return <LoginPage onLogin={() => setIsLoggedIn(true)} />;
  }
  const currentProject = projects.find(p => p.id === activeProjectId);

  // 🚑 安全氣囊：如果找不到專案（例如 ID 對不上），就先顯示載入中或錯誤，防止程式當機
  if (!currentProject) {
    return (
      <div style={{ color: 'white', padding: '50px', textAlign: 'center' }}>
        <h2>⚠️ 發生錯誤</h2>
        <p>找不到 ID 為 {activeProjectId} 的專案資料。</p>
        <button onClick={() => setProjects(initialProjects)}>重置資料</button>
      </div>
    );
  }

  // 篩選邏輯 (後面保持不變)...
  // 篩選邏輯 (保持不變)
  const filteredData = currentProject.data.filter(item => {
    if (!searchTerm) return true;
    const lowerText = searchTerm.toLowerCase();
    return (
      item.prompt.toLowerCase().includes(lowerText) || 
      item.response.toLowerCase().includes(lowerText) ||
      (item.tags && item.tags.some(tag => tag.toLowerCase().includes(lowerText)))
    );
  });
  
// ★★★ 更新功能★★★
  const handleUpdate = (id, newPrompt, newResponse) => {
    const newProjects = projects.map(p => {
      // 1. 先找到目前選中的專案
      if (p.id === activeProjectId) {
        // 2. 接著在專案的資料裡，找到那筆特定的 ID
        const newData = p.data.map(item => {
          if (item.id === id) {
            // 3. 只有這筆資料要更新：保留原本的 ID 和日期，但換上新的 prompt 和 response
            return { ...item, prompt: newPrompt, response: newResponse };
          }
          return item; // 其他資料不動
        });
        return { ...p, data: newData }; // 更新專案資料
      }
      return p; // 其他專案不動
    });
    setProjects(newProjects); // 存回大腦
  };

// ★★★ 新增功能：處理新資料 (接收 文字 + 標籤) ★★★
  const handleNewPrompt = (newPrompt, newTags) => {
    const newProjects = projects.map(p => {
      // 找到目前選中的專案
      if (p.id === activeProjectId) {
        const newItem = {
          id: Date.now(), // 用時間當作 ID
          version: "v" + (p.data.length + 1) + ".0",
          date: new Date().toISOString().slice(0, 10),
          tags: newTags, // ★ 這裡！把傳進來的標籤存進去
          prompt: newPrompt,
          response: "（這是模擬的 AI 回應...）"
        };
        // 把新項目加在最前面
        return { ...p, data: [newItem, ...p.data] };
      }
      return p;
    });
    setProjects(newProjects);
  };

  // ★★★ 刪除功能 ★★★
  const handleDelete = (itemId) => {
    // 使用 confirm 做一個簡單的防呆確認
    if (window.confirm("確定要刪除這筆資料嗎？")) {
      const newProjects = projects.map(p => {
        // 找到目前的專案
        if (p.id === activeProjectId) {
          // 過濾掉要刪除的那個 ID
          const newData = p.data.filter(item => item.id !== itemId);
          return { ...p, data: newData };
        }
        return p;
      });
      setProjects(newProjects); // 更新狀態
    }
  };

  return (
    <div className="app-container">
      <Sidebar 
        projects={projects} 
        activeProjectId={activeProjectId} 
        onSelect={(id) => {
          setActiveProjectId(id);
          setSearchTerm("");
        }}
        user={mockUser}                  // 傳送使用者資料
        onLogout={() => setIsLoggedIn(false)} // 傳送登出功能 (把狀態改回 false)
      />
      
      <div style={{ marginLeft: '260px' }}>
        <Header 
          searchTerm={searchTerm}
          onSearch={(text) => setSearchTerm(text)}
        />
        
        <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto', paddingBottom: '100px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
             <h2>🗂️ {currentProject.name}</h2>
             <span style={{ color: '#8b949e', fontSize: '0.9rem' }}>
               共 {filteredData.length} 筆資料
             </span>
          </div>
          
          {filteredData.length > 0 ? (
            filteredData.map((item) => (
              <ContentCard 
                key={item.id}
                id={item.id}     // 記得傳 ID，刪除時才找得到人
                version={item.version}
                date={item.date}
                tags={item.tags}
                prompt={item.prompt}
                response={item.response}
                onDelete={handleDelete} // ★★★ 2. 把刪除功能傳進去
                onUpdate={handleUpdate}
              />
            ))
          ) : (
            <div style={{ textAlign: 'center', color: '#8b949e', marginTop: '50px' }}>
              <p>🔍 找不到含有「{searchTerm}」的內容...</p>
            </div>
          )}
        </div>

        <PromptInput onNewPrompt={handleNewPrompt} />
      </div>
    </div>
  )
}

export default App